#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);
    printf("Hello world %d", n);
    return 0;
}